import { useState, useEffect } from "react";
import { Alert } from "react-bootstrap";
import Login from "./Login";
import "./login.css"

function Registration() {
  
  const [formValues, setFormValues] = useState({ 
  username: "", 
  email: "", 
  password: "",
  confirmPassword:""});
  const [formErrors, setFormErrors] = useState({});
  const [isSubmit, setIsSubmit] = useState(false);
  const [login,setLogin] =useState(true);

const{username, email, password, confirmPassword}=formValues;

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormValues({ ...formValues, [name]: value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    setFormErrors(validate(formValues));
    if(!username || !email || !password || !confirmPassword){
        setIsSubmit(true)
    }  else {
        setIsSubmit(false);
        localStorage.setItem("Email",email);
        localStorage.setItem("Password",password);
        alert("User Registration Successfully")
        setLogin(!login);
}
  };

  useEffect(() => {
    console.log(formErrors);
    if (Object.keys(formErrors).length === 0 && isSubmit) {
      console.log(formValues);
    } 
  }, [formErrors]);
  const validate = (values) => {
    const errors = {};
    const regex = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/i;
    if (!values.username) {
      errors.username = "Username is required!";
    }
    if (!values.email) {
      errors.email = "Email is required!";
    } else if (!regex.test(values.email)) {
      errors.email = "This is not a valid email format!";
    }
    if (!values.password) {
      errors.password = "Password is required";
    } else if (values.password.length < 4) {
      errors.password = "Password must be more than 4 characters";
    } else if (values.password.length > 10) {
      errors.password = "Password cannot exceed more than 10 characters";
    }
    if (!values.confirmPassword){
        errors.confirmPassword = "Password is required";
    } else if (values.password !== values.confirmPassword){
        errors.confirmPassword = "Password not matching";
    }
    return errors;
  };
  function handleClick() {
    setLogin(!login);
}

  return (
    <div id="container">
     
    {login ? (
      <form onSubmit={handleSubmit}>
        <h1>Register </h1>
        <div className="ui divider"></div>
        <div className="ui form">
          <div className="field">
            <label>Username</label>
            <br/>
            <input type="text" name="username" placeholder="Username" value={formValues.username} onChange={handleChange} required />
          </div>
          <p>{formErrors.username}</p>
          <div className="field">
            <label>Email</label>
            <br/>
            <input type="email" name="email" placeholder="abc@xyz.com" value={formValues.email} onChange={handleChange} required />
          </div>
          <p>{formErrors.email}</p>
          <div className="field">
            <label>Password</label>
            <br/>
            <input type="password" name="password" placeholder="#########" value={formValues.password} onChange={handleChange} required/>
          </div>
          <p>{formErrors.password}</p>
          <div className="field">
            <label>ConfirmPassword</label>
            <br/>
            <input type="password" name="confirmPassword" placeholder="#########" value={formValues.confirmPassword} onChange={handleChange} required/>
          </div>
          <p>{formErrors.confirmPassword}</p>
          <button className="fluid ui button blue">Submit</button>
          </div>
    
          <span >Already registered</span> <button onClick={handleClick}>login </button>
          { isSubmit && (
                    <Alert color="primary" variant="danger">
                    Please fill Every Field </Alert>
                )}
        
      </form>
      ):(
          <Login/>
      )}
    </div>
  );
}

export default Registration;