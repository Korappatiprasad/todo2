import logo from './logo.svg';
import './App.css';
import Registration from './Components/Registration';

function App() {
  return (
    <div className="App">
    <Registration></Registration>
    </div>
  );
}

export default App;
